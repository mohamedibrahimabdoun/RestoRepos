/*
 * jSOAP version	: 1.0-alpha (06/01/2010)
 * File version		: 1.0-alpha (05/26/2010)
 * 
 * � Copyright 2010 WALTHER J�r�my.
 * e-mail : golflima@ftad.fr
 * 
 * jSOAP is available on SourceForge :
 * https://sourceforge.net/projects/jsoap/
 * 
 * This file is part of jSOAP (Java Client for Mobile).
 *
 * jSOAP is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * jSOAP is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with jSOAP.  If not, see <http://www.gnu.org/licenses/>.
 */

package com.ftad.jsoap.mobile;

public class JSOAPValueIterator 
{
	private JSOAPValueChained values;
	private boolean hasNext;
	
	public JSOAPValueIterator()
	{
		this.values = new JSOAPValueChained();
		this.hasNext = false;
	}
	
	public JSOAPValueIterator(JSOAPValueChained values)
	{
		this.values = values;
		this.hasNext = values.hasValue();
	}
	
	public boolean hasNext()
	{
		return this.hasNext;
	}
	
	public boolean hasValue()
	{
		return this.values.hasValue();
	}
	
	public boolean isSet()
	{
		return (this.values != null);
	}
	
	public JSOAPValue next()
	{
		if (this.values.hasValue())
		{
			if (this.values.hasNext())
			{
				JSOAPValue previous = this.values.getValue();
				this.values = this.values.getNext();
				return previous;
			}
			else
			{
				this.hasNext = false;
				return this.values.getValue();
			}
		}
		this.hasNext = false;
		return null;
	}
	
	public String toString()
	{
		StringBuffer tmp = new StringBuffer();
		JSOAPValueChained it = this.values;
		if (it.hasValue())
			tmp.append(it.getValue().toString());
		while (it.hasNext())
		{
			it = it.getNext();
			tmp.append(it.getValue().toString());
		}
		return tmp.toString();
	}
}
