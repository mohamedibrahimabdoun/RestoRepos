/*
 * jSOAP version	: 1.0-alpha (06/01/2010)
 * File version		: 1.0-alpha (05/26/2010)
 * 
 * � Copyright 2010 WALTHER J�r�my.
 * e-mail : golflima@ftad.fr
 * 
 * jSOAP is available on SourceForge :
 * https://sourceforge.net/projects/jsoap/
 * 
 * This file is part of jSOAP (Java Client for Mobile).
 *
 * jSOAP is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * jSOAP is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with jSOAP.  If not, see <http://www.gnu.org/licenses/>.
 */

package com.ftad.jsoap.mobile;

public class JSOAPOperation extends JSOAPElement
{
	JSOAPValues values;
	
	public JSOAPOperation(String operation)
	{
		super("", "<nsJSOAP:"+operation+" xmlns:nsJSOAP=\"http://tempuri.org\">", "</nsJSOAP:"+operation+">");
		this.values = new JSOAPValues();
	}
	
	public JSOAPOperation()
	{
		super("", "<nsJSoap:Operation>", "</nsJSoap:Operation>");
		this.values = new JSOAPValues();
	}
	
	public JSOAPValues getValues() 
	{
		return values;
	}

	public void setValues(JSOAPValues values) 
	{
		this.values = values;
		this.setContent(values.toString());
	}

	public void setFromString(String xml)
	{
		int first = xml.indexOf('<') + 1;
		if (first != 0)
		{
			int last = xml.indexOf(' ');
			if (xml.indexOf('>') < last)
			{
				last = xml.indexOf('>');
			}
			super.setFromString(xml, xml.substring(first, last));
			if (this.getContent() != "")
			{
				StringBuffer tmp = new StringBuffer(this.getContent());
				int pos = 0;
				while ((this.values.toString().length() != this.getContent().length()) && (pos != -1))
				{
					JSOAPValue value = new JSOAPValue();
					value.setFromString(tmp.toString());
					pos = tmp.toString().indexOf(value.toString());
					if (pos != -1)
					{
						tmp.delete(pos, pos + value.toString().length());
						this.values.add(value);
					}
				}
			}
		}
	}
}
