/*
 * jSOAP version	: 1.0-alpha (06/01/2010)
 * File version		: 1.0-alpha (05/26/2010)
 * 
 * � Copyright 2010 WALTHER J�r�my.
 * e-mail : golflima@ftad.fr
 * 
 * jSOAP is available on SourceForge :
 * https://sourceforge.net/projects/jsoap/
 * 
 * This file is part of jSOAP (Java Client for Mobile).
 *
 * jSOAP is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * jSOAP is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with jSOAP.  If not, see <http://www.gnu.org/licenses/>.
 */

package com.ftad.jsoap.mobile;

public class JSOAPValueChained
{
	private JSOAPValueChained next;
	private JSOAPValue value;
	private int index;
	
	public JSOAPValueChained()
	{
		this.index = 0;
		this.value = null;
		this.next = null;
	}
	
	public JSOAPValueChained(int index)
	{
		this.index = index;
		this.value = null;
		this.next = null;
	}
	
	public JSOAPValueChained(JSOAPValue value)
	{
		this.index = 0;
		this.value = value;
		this.next = null;
	}
	
	public JSOAPValueChained(int index, JSOAPValue value)
	{
		this.index = index;
		this.value = value;
		this.next = null;
	}
	
	public JSOAPValueChained(int index, JSOAPValue value, JSOAPValueChained next)
	{
		this.index = index;
		this.value = value;
		this.next = next;
	}

	public JSOAPValueChained getNext() 
	{
		return next;
	}

	public void setNext(JSOAPValueChained next) 
	{
		this.next = next;
	}

	public JSOAPValue getValue() 
	{
		return value;
	}

	public void setValue(JSOAPValue value) 
	{
		this.value = value;
	}

	public int getIndex()
	{
		return index;
	}

	public void setIndex(int index) 
	{
		this.index = index;
	}
	
	public boolean hasNext()
	{
		return (this.next != null);
	}
	
	public boolean isSet()
	{
		return (this.value != null);
	}
	
	public boolean hasValue()
	{
		return this.isSet();
	}
	
	public String toString()
	{
		StringBuffer tmp = new StringBuffer();
		if (this.hasValue())
		{
			tmp.append('(').append(index).append('|').append(this.value.getName()).append(' ');
			if (this.hasNext())
			{
				tmp.append(this.next.toString());
			}
			else
			{
				tmp.append("NULL");
			}
			tmp.append(')');
		}
		else
		{
			tmp.append("(NULL)");
		}
		return tmp.toString();
	}
}
