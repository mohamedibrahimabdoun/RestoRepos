/*
 * jSOAP version	: 1.0-alpha (06/01/2010)
 * File version		: 1.0-alpha (06/01/2010)
 * 
 * � Copyright 2010 WALTHER J�r�my.
 * e-mail : golflima@ftad.fr
 * 
 * jSOAP is available on SourceForge :
 * https://sourceforge.net/projects/jsoap/
 * 
 * This file is part of jSOAP (Java Client for Mobile).
 *
 * jSOAP is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * jSOAP is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with jSOAP.  If not, see <http://www.gnu.org/licenses/>.
 */

package com.ftad.jsoap.mobile;

public class JSOAPFault extends JSOAPElement
{
	private JSOAPValue faultcode;
	private JSOAPValue faultstring;
	private JSOAPValue faultactor;
	private JSOAPValue detail;
	private boolean isset;
	
	public JSOAPFault()
	{
		super();
		this.faultcode = null;
		this.faultstring = null;
		this.faultactor = null;
		this.detail = null;
		this.isset = false;
	}
	
	public JSOAPFault(JSOAPValues result)
	{
		super.setStart("");
		super.setContent(result.toString());
		super.setEnd("");
		
		int c = 0;
		JSOAPValueIterator it_fault = result.getIterator();
		while (it_fault.hasNext())
		{
			JSOAPValue fault = it_fault.next();
			if (fault.getName().equalsIgnoreCase("fault"))
			{
				super.setStart(fault.getStart());
				super.setContent(fault.getContent());
				super.setEnd(fault.getEnd());
				JSOAPValueIterator it_value = fault.getValues().getIterator();
				while (it_value.hasNext())
				{
					JSOAPValue value = it_value.next();
					if (value.getName().equalsIgnoreCase("faultcode"))
					{
						this.faultcode = value;
						c++;
					}
					else if (value.getName().equalsIgnoreCase("faultstring"))
					{
						this.faultstring = value;
						c++;
					}
					else if (value.getName().equalsIgnoreCase("faultactor"))
					{
						this.faultactor = value;
						c++;
					}
					else if (value.getName().equalsIgnoreCase("detail"))
					{
						this.detail = value;
						c++;
					}
				}
			}
			else
			{
				if (fault.getName().equalsIgnoreCase("faultcode"))
				{
					this.faultcode = fault;
					c++;
				}
				else if (fault.getName().equalsIgnoreCase("faultstring"))
				{
					this.faultstring = fault;
					c++;
				}
				else if (fault.getName().equalsIgnoreCase("faultactor"))
				{
					this.faultactor = fault;
					c++;
				}
				else if (fault.getName().equalsIgnoreCase("detail"))
				{
					this.detail = fault;
					c++;
				}
			}
		}
		if (c == 4)
		{
			this.isset = true;
		}
	}

	public JSOAPValue getFaultcode() 
	{
		return faultcode;
	}

	public void setFaultcode(JSOAPValue faultcode)
	{
		this.faultcode = faultcode;
	}

	public JSOAPValue getFaultstring() 
	{
		return faultstring;
	}

	public void setFaultstring(JSOAPValue faultstring) 
	{
		this.faultstring = faultstring;
	}

	public JSOAPValue getFaultactor() 
	{
		return faultactor;
	}

	public void setFaultactor(JSOAPValue faultactor) 
	{
		this.faultactor = faultactor;
	}

	public JSOAPValue getDetail() 
	{
		return detail;
	}

	public void setDetail(JSOAPValue detail) 
	{
		this.detail = detail;
	}

	public boolean isSet() 
	{
		return isset;
	}

	public String getError()
	{
		if (this.isset)
			return this.faultstring.getContent();
		return null;
	}
}
