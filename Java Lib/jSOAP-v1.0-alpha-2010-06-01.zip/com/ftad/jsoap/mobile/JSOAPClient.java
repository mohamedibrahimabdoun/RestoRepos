/*
 * jSOAP version	: 1.0-alpha (06/01/2010)
 * File version		: 1.0-alpha (05/31/2010)
 * 
 * � Copyright 2010 WALTHER J�r�my.
 * e-mail : golflima@ftad.fr
 * 
 * jSOAP is available on SourceForge :
 * https://sourceforge.net/projects/jsoap/
 * 
 * This file is part of jSOAP (Java Client for Mobile).
 *
 * jSOAP is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * jSOAP is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with jSOAP.  If not, see <http://www.gnu.org/licenses/>.
 */

package com.ftad.jsoap.mobile;
import java.io.*;
import javax.microedition.io.*;

import java.util.Enumeration;
import java.util.Hashtable;

public class JSOAPClient 
{
	private JSOAPMessage request;
	private JSOAPMessage response;
	private String target;
	private String headers;
	private JSOAPFault fault;

	public JSOAPClient(String target)
	{
		this.target = target;
		this.request = new JSOAPMessage();
		this.response = new JSOAPMessage();
		this.fault = new JSOAPFault();
	}
	
	public String getHeaders() 
	{
		return headers;
	}

	public void setHeaders(String headers) 
	{
		this.headers = headers;
	}

	public JSOAPMessage getRequest() 
	{
		return request;
	}

	public void setRequest(JSOAPMessage request) 
	{
		this.request = request;
	}

	public JSOAPMessage getResponse() 
	{
		return response;
	}

	public void setResponse(JSOAPMessage response) 
	{
		this.response = response;
	}

	public String getTarget() 
	{
		return target;
	}

	public void setTarget(String target) 
	{
		this.target = target;
	}
	
	public JSOAPMessage call(String command, Hashtable parameters) throws Exception
	{ 
		JSOAPValues values = new JSOAPValues();
		Enumeration keys = parameters.keys();
		while (keys.hasMoreElements())
        {
            String key = (String) keys.nextElement();
            values.add(new JSOAPValue(key, (String) parameters.get(key)));
        }
        
        return this.call(command, values);
	}
	
	public JSOAPMessage call(String command, JSOAPValues parameters) throws Exception
	{
		this.request = new JSOAPMessage();
		this.response = new JSOAPMessage();
		this.fault = new JSOAPFault();
        this.request.getHeader().setContent(this.headers);
		JSOAPOperation operation = new JSOAPOperation(command);
		operation.setValues(parameters);
		this.request.getBody().setOperation(operation);
		this.response.setFromString(this.send(this.request.toString()));
		
        this.fault = new JSOAPFault(this.getResult());
        if (this.fault.isSet())
        {
        	return null;
        }
        return this.response;
	}
	
	public String send(String xml) throws Exception
	{
        HttpConnection httpConn = (HttpConnection) Connector.open(this.target);
		
		httpConn.setRequestProperty("Content-Length",String.valueOf(xml.getBytes()));
		httpConn.setRequestProperty("Content-Type","text/xml; charset=ISO-8859-1");
		httpConn.setRequestProperty("SOAPAction","");
		httpConn.setRequestMethod(HttpConnection.POST);
		
		OutputStream out = httpConn.openOutputStream();
        out.write(xml.getBytes());
        out.flush();
        out.close();
        
        InputStreamReader isr = new InputStreamReader(httpConn.openDataInputStream());

        StringBuffer result = new StringBuffer();
        char buffer[] = new char[1024];
        int length = 0;
        while ((length = isr.read(buffer)) != -1)
            result.append(buffer, 0, length);

        isr.close();
        
        httpConn.close();
        
        return result.toString();
	}
	
	public JSOAPValues getResult()
	{
		if (this.fault.isSet())
			return null;
		return this.response.getBody().getOperation().getValues();
	}
	
	public JSOAPFault getFault()
	{
		return this.fault;
	}
	
	public String getError()
	{
		return this.fault.getError();
	}
	
	public boolean isFault()
	{
		return this.fault.isSet();
	}
	
	public boolean isError()
	{
		return this.isFault();
	}
}
