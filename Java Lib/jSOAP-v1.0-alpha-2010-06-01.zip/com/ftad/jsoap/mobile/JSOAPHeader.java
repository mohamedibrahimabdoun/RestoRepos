/*
 * jSOAP version	: 1.0-alpha (06/01/2010)
 * File version		: 1.0-alpha (05/26/2010)
 * 
 * � Copyright 2010 WALTHER J�r�my.
 * e-mail : golflima@ftad.fr
 * 
 * jSOAP is available on SourceForge :
 * https://sourceforge.net/projects/jsoap/
 * 
 * This file is part of jSOAP (Java Client for Mobile).
 *
 * jSOAP is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * jSOAP is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with jSOAP.  If not, see <http://www.gnu.org/licenses/>.
 */

package com.ftad.jsoap.mobile;

public class JSOAPHeader extends JSOAPElement
{
	public JSOAPHeader(String content)
	{
		super("Header", content);
	}
	
	public JSOAPHeader()
	{
		super("Header");
	}
	
	public void setFromString(String xml)
	{
		super.setFromString(xml, "SOAP-ENV:Header");
	}
}
