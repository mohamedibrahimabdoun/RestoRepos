/*
 * jSOAP version	: 1.0-alpha (06/01/2010)
 * File version		: 1.0-alpha (05/31/2010)
 * 
 * � Copyright 2010 WALTHER J�r�my.
 * e-mail : golflima@ftad.fr
 * 
 * jSOAP is available on SourceForge :
 * https://sourceforge.net/projects/jsoap/
 * 
 * This file is part of jSOAP (Java Client for Mobile).
 *
 * jSOAP is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * jSOAP is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with jSOAP.  If not, see <http://www.gnu.org/licenses/>.
 */

package com.ftad.jsoap.mobile;

public class JSOAPValues
{
	private JSOAPValueChained values;
	private int size;
	
	public JSOAPValues()
	{
		this.values = new JSOAPValueChained();
		this.size = 0;
	}
	
	public JSOAPValue get(int index)
	{
		if (index <= this.size)
		{
			JSOAPValueChained pos = this.values;
			while (pos.getIndex() != index && pos.getNext() != null)
			{
				pos = pos.getNext();
			}
			if (pos.getIndex() == index)
				return pos.getValue();
		}
		return null;
	}
	
	public int size()
	{
		return this.size;
	}
	
	public int computeSize()
	{
		JSOAPValueChained pos = this.values;
		int size = 0;
		while (pos.hasNext())
		{
			size = pos.getIndex();
			pos = pos.getNext();
		}
		return size;
	}
	
	public void add(JSOAPValue value)
	{
		if (this.size > 0)
		{
			JSOAPValueChained chain = this.values;
			while (chain.hasNext())
			{
				chain = chain.getNext();
			}
			++this.size;
			chain.setNext(new JSOAPValueChained(chain.getIndex() + 1, value));
		}
		else
		{
			values = new JSOAPValueChained(0, value);
			++this.size;
		}
	}
	
	public String toString()
	{
		StringBuffer tmp = new StringBuffer();
		JSOAPValueChained it = this.values;
		if (it.hasValue())
			tmp.append(it.getValue().toString());
		while (it.hasNext())
		{
			it = it.getNext();
			tmp.append(it.getValue().toString());
		}
		return tmp.toString();
	}
	
	public JSOAPValueIterator getIterator()
	{
		return new JSOAPValueIterator(this.values);
	}
	
	public JSOAPValueIterator iterator()
	{
		return this.getIterator();
	}
	
	public JSOAPValueChained getChain()
	{
		return this.values;
	}
}
