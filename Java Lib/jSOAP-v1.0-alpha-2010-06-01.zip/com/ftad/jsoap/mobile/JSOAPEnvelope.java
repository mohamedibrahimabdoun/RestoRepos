/*
 * jSOAP version	: 1.0-alpha (06/01/2010)
 * File version		: 1.0-alpha (05/26/2010)
 * 
 * � Copyright 2010 WALTHER J�r�my.
 * e-mail : golflima@ftad.fr
 * 
 * jSOAP is available on SourceForge :
 * https://sourceforge.net/projects/jsoap/
 * 
 * This file is part of jSOAP (Java Client for Mobile).
 *
 * jSOAP is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * jSOAP is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with jSOAP.  If not, see <http://www.gnu.org/licenses/>.
 */

package com.ftad.jsoap.mobile;

public class JSOAPEnvelope extends JSOAPElement
{
	private JSOAPHeader header;
	private JSOAPBody body;
	
	public JSOAPEnvelope(JSOAPHeader header)
	{
		super("", "<SOAP-ENV:Envelope SOAP-ENV:encodingStyle=\"http://schemas.xmlsoap.org/soap/encoding/\" xmlns:SOAP-ENV=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:SOAP-ENC=\"http://schemas.xmlsoap.org/soap/encoding/\">", "</SOAP-ENV:Envelope>");
		this.header = header;
		this.body = new JSOAPBody();
	}
	
	public JSOAPEnvelope(JSOAPBody body)
	{
		super("", "<SOAP-ENV:Envelope SOAP-ENV:encodingStyle=\"http://schemas.xmlsoap.org/soap/encoding/\" xmlns:SOAP-ENV=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:SOAP-ENC=\"http://schemas.xmlsoap.org/soap/encoding/\">", "</SOAP-ENV:Envelope>");
		this.header = new JSOAPHeader();
		this.body = body;
	}
	
	public JSOAPEnvelope(JSOAPHeader header, JSOAPBody body)
	{
		super("", "<SOAP-ENV:Envelope SOAP-ENV:encodingStyle=\"http://schemas.xmlsoap.org/soap/encoding/\" xmlns:SOAP-ENV=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:SOAP-ENC=\"http://schemas.xmlsoap.org/soap/encoding/\">", "</SOAP-ENV:Envelope>");
		this.header = header;
		this.body = body;
	}
	
	public JSOAPEnvelope()
	{
		super("", "<SOAP-ENV:Envelope SOAP-ENV:encodingStyle=\"http://schemas.xmlsoap.org/soap/encoding/\" xmlns:SOAP-ENV=\"http://schemas.xmlsoap.org/soap/envelope/\" xmlns:xsd=\"http://www.w3.org/2001/XMLSchema\" xmlns:xsi=\"http://www.w3.org/2001/XMLSchema-instance\" xmlns:SOAP-ENC=\"http://schemas.xmlsoap.org/soap/encoding/\">", "</SOAP-ENV:Envelope>");
		this.header = new JSOAPHeader();
		this.body = new JSOAPBody();
	}

	public JSOAPHeader getHeader() 
	{
		return header;
	}

	public void setHeader(JSOAPHeader header) 
	{
		this.header = header;
	}

	public JSOAPBody getBody() 
	{
		return body;
	}

	public void setBody(JSOAPBody body) 
	{
		this.body = body;
	}
	
	public String toString()
	{
		StringBuffer tmp = new StringBuffer();
		tmp.append(this.header).append(this.body);
		super.setContent(tmp.toString());
		return super.toString();
	}
}
